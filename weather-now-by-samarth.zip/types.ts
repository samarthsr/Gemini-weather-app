
export enum WeatherCondition {
  SUNNY = 'SUNNY',
  CLOUDY = 'CLOUDY',
  RAINY = 'RAINY',
  SNOWY = 'SNOWY',
  WINDY = 'WINDY',
  THUNDERSTORM = 'THUNDERSTORM',
  UNKNOWN = 'UNKNOWN'
}

export interface WeatherData {
  city: string;
  country: string;
  temperatureCelsius: number;
  humidity: number;
  windSpeedKmh: number;
  description: string;
  icon: WeatherCondition;
}

export interface GroundingSource {
  web: {
    uri: string;
    title: string;
  };
}
