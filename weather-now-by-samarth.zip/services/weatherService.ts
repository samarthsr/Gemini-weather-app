
import { GoogleGenAI } from "@google/genai";
import type { WeatherData, GroundingSource } from '../types';
import { WeatherCondition } from '../types';


// This is a simplified check. In a real app, you'd want more robust validation.
const isWeatherData = (obj: any): obj is WeatherData => {
  return (
    typeof obj === 'object' &&
    obj !== null &&
    typeof obj.city === 'string' &&
    typeof obj.country === 'string' &&
    typeof obj.temperatureCelsius === 'number' &&
    typeof obj.humidity === 'number' &&
    typeof obj.windSpeedKmh === 'number' &&
    typeof obj.description === 'string' &&
    Object.values(WeatherCondition).includes(obj.icon)
  );
};

export const getWeatherForCity = async (
  city: string
): Promise<{ weather: WeatherData; sources: GroundingSource[] } | null> => {
  // This check is crucial to ensure the API key is available.
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set.");
  }
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const prompt = `
    Provide the current weather for the city: ${city}.
    Respond with ONLY a single, valid JSON object. Do not include any text, backticks, or markdown before or after the JSON object.
    The JSON object must contain these exact keys:
    - "city": The name of the city.
    - "country": The country of the city.
    - "temperatureCelsius": The current temperature in Celsius (as a number).
    - "humidity": The current humidity percentage (as a number).
    - "windSpeedKmh": The current wind speed in kilometers per hour (as a number).
    - "description": A brief, one or two-word weather description (e.g., "Sunny", "Partly Cloudy").
    - "icon": A single-word icon identifier from this list: [${Object.values(WeatherCondition).join(', ')}]. Choose the most appropriate one.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    let jsonString = response.text.trim();
    
    // Clean the response: Gemini can sometimes wrap the JSON in a markdown code block.
    const jsonRegex = /```json\s*([\s\S]*?)\s*```/;
    const match = jsonString.match(jsonRegex);
    if (match && match[1]) {
      jsonString = match[1];
    }
    
    const weatherData = JSON.parse(jsonString);

    if (!isWeatherData(weatherData)) {
      console.error("Parsed data does not match WeatherData interface:", weatherData);
      throw new Error("Received malformed weather data from API.");
    }

    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const sources = groundingChunks.filter((chunk: any): chunk is GroundingSource => 
        chunk && chunk.web && typeof chunk.web.uri === 'string' && typeof chunk.web.title === 'string'
    );

    return { weather: weatherData, sources };
  } catch (error) {
    console.error("Error fetching or parsing weather data:", error);
    if (error instanceof SyntaxError) {
      throw new Error("Failed to parse the weather data from the API. The response may not be valid JSON.");
    }
    // Re-throw other errors to be handled by the caller
    throw error;
  }
};
