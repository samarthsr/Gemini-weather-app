
import React from 'react';
import type { GroundingSource } from '../types';

interface SourceListProps {
  sources: GroundingSource[];
}

const SourceList: React.FC<SourceListProps> = ({ sources }) => {
  if (sources.length === 0) {
    return null;
  }

  return (
    <div className="bg-black/20 backdrop-blur-sm rounded-lg p-4 w-full max-w-md animate-fade-in">
      <h3 className="text-sm font-semibold text-gray-300 mb-2">Data Sources:</h3>
      <ul className="space-y-1 list-disc list-inside">
        {sources.map((source, index) => (
          <li key={index} className="truncate">
            <a
              href={source.web.uri}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-300 hover:text-blue-400 text-xs transition-colors"
              title={source.web.title || source.web.uri}
            >
              {source.web.title || source.web.uri}
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default SourceList;
