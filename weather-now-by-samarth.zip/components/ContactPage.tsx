import React from 'react';

const ContactPage: React.FC = () => {
  return (
    <div className="w-full max-w-md flex-grow flex flex-col items-center justify-center animate-fade-in">
      <div className="bg-white/20 backdrop-blur-lg rounded-xl shadow-2xl p-8 w-full text-white space-y-6">
        <div className="text-center">
          <h2 className="text-3xl font-bold">About Weather Now</h2>
          <p className="text-gray-300 text-sm mt-1">Version 1.0</p>
        </div>

        <div className="text-center text-lg">
          <p>This application was developed by <span className="font-semibold">Samarth SR</span>.</p>
        </div>

        <div>
          <h3 className="text-xl font-bold mb-2 border-b border-white/20 pb-1">Contact Information</h3>
          <div className="space-y-2 text-base pt-2">
            <div className="flex items-center">
              <span className="w-24 font-semibold">Name:</span>
              <span>Samarth Ronad</span>
            </div>
            <div className="flex items-center">
              <span className="w-24 font-semibold">Email:</span>
              <a href="mailto:samarthsr333@gmail.com" className="text-blue-300 hover:text-blue-400 transition-colors">
                samarthsr333@gmail.com
              </a>
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-xl font-bold mb-2 border-b border-white/20 pb-1">API Key Security</h3>
          <p className="text-sm text-gray-300 pt-2">
            For security, API keys should not be exposed in client-side code. This app uses a placeholder for an environment variable (`process.env.API_KEY`) which should be managed on a secure server. In a production environment, all API calls should be routed through a backend proxy that holds the secret key.
          </p>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;
