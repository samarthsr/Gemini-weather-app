
import React from 'react';
import type { WeatherData } from '../types';
import WeatherIcon from './WeatherIcon';

interface WeatherCardProps {
  data: WeatherData;
}

const WeatherCard: React.FC<WeatherCardProps> = ({ data }) => {
  return (
    <div className="bg-white/20 backdrop-blur-lg rounded-xl shadow-2xl p-8 w-full max-w-md text-white animate-fade-in">
      <div className="text-center mb-6">
        <h2 className="text-3xl font-bold">{data.city}, {data.country}</h2>
        <p className="text-lg text-gray-200">{data.description}</p>
      </div>
      <div className="flex justify-center items-center mb-6">
        <div className="w-32 h-32">
          <WeatherIcon condition={data.icon} />
        </div>
        <p className="text-7xl font-extrabold ml-4">{Math.round(data.temperatureCelsius)}°C</p>
      </div>
      <div className="flex justify-around text-center bg-black/20 p-4 rounded-lg">
        <div>
          <p className="text-sm text-gray-300">Humidity</p>
          <p className="text-xl font-semibold">{data.humidity}%</p>
        </div>
        <div>
          <p className="text-sm text-gray-300">Wind Speed</p>
          <p className="text-xl font-semibold">{data.windSpeedKmh} km/h</p>
        </div>
      </div>
    </div>
  );
};

export default WeatherCard;
