
import React from 'react';
import { WeatherCondition } from '../types';

interface WeatherIconProps {
  condition: WeatherCondition;
  className?: string;
}

const SunnyIcon: React.FC<{className?: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="5"></circle>
    <line x1="12" y1="1" x2="12" y2="3"></line>
    <line x1="12" y1="21" x2="12" y2="23"></line>
    <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
    <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
    <line x1="1" y1="12" x2="3" y2="12"></line>
    <line x1="21" y1="12" x2="23" y2="12"></line>
    <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
    <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
  </svg>
);

const CloudyIcon: React.FC<{className?: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"></path>
  </svg>
);

const RainyIcon: React.FC<{className?: string}> = ({className}) => (
 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M23 12a11.05 11.05 0 0 0-22 0zm-5 7a3 3 0 0 1-6 0"></path>
    <path d="M12 12v7"></path>
    <path d="M16 12v7"></path>
    <path d="M8 12v7"></path>
    <path d="M12 2v4"></path>
    <path d="m4.93 4.93 2.83 2.83"></path>
    <path d="m19.07 4.93-2.83 2.83"></path>
  </svg>
);

const SnowyIcon: React.FC<{className?: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M20 17.58A5 5 0 0 0 18 8h-1.26A8 8 0 1 0 4 16.25"></path>
    <line x1="8" y1="16" x2="8" y2="16"></line><line x1="8" y1="20" x2="8" y2="20"></line>
    <line x1="12" y1="18" x2="12" y2="18"></line><line x1="12" y1="22" x2="12" y2="22"></line>
    <line x1="16" y1="16" x2="16" y2="16"></line><line x1="16" y1="20" x2="16" y2="20"></line>
  </svg>
);

const WindyIcon: React.FC<{className?: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M9.59 4.59A2 2 0 1 1 11 8H2"></path>
    <path d="M12.66 16.34A2 2 0 1 1 14 20H2"></path>
    <path d="M14.5 12H2"></path>
  </svg>
);

const ThunderstormIcon: React.FC<{className?: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M21 16.92V17a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-.08A4.98 4.98 0 0 1 5 7c0-2.21 1.79-4 4-4h.31A2.5 2.5 0 0 1 12 5.3V4a2 2 0 0 1 2-2h1a2 2 0 0 1 2 2v1.31a2.5 2.5 0 0 1 2.69 3.19A4.98 4.98 0 0 1 21 16.92z"></path>
    <polyline points="13 11 10 16 13 16 11 21"></polyline>
  </svg>
);

const WeatherIcon: React.FC<WeatherIconProps> = ({ condition, className = 'w-full h-full text-white' }) => {
  switch (condition) {
    case WeatherCondition.SUNNY:
      return <SunnyIcon className={className} />;
    case WeatherCondition.CLOUDY:
      return <CloudyIcon className={className} />;
    case WeatherCondition.RAINY:
      return <RainyIcon className={className} />;
    case WeatherCondition.SNOWY:
      return <SnowyIcon className={className} />;
    case WeatherCondition.WINDY:
      return <WindyIcon className={className} />;
    case WeatherCondition.THUNDERSTORM:
      return <ThunderstormIcon className={className} />;
    default:
      return <CloudyIcon className={className} />;
  }
};

export default WeatherIcon;
